package com.senai.conversor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversorApplicationTests {

	@Test
	void contextLoads() {
	}

}
